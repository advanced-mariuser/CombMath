#include "CGammaAlgorithm.h"

CGammaAlgorithm::CGammaAlgorithm(CGraph& graph) : m_graph(graph), m_graphFilled(graph.GetVertexCount()) {}

void CGammaAlgorithm::Run() {
    Initialize();
    GeneralStep();
    Completion();
}

void CGammaAlgorithm::Initialize() {
    m_cycle = m_graph.FindCycle();
    if (m_cycle.empty()) {
        std::cerr << "No cycle found in the graph during initialization." << std::endl;
        return;
    }
    for (size_t i = 0; i < m_cycle.size() - 1; ++i) {
        m_graphFilled.AddEdge(m_cycle[i], m_cycle[i + 1]);
    }
    m_graphFilled.AddEdge(m_cycle.back(), m_cycle.front());
}

void CGammaAlgorithm::GeneralStep() {
    while (true) {
        bool added = false;
        for (int v = 0; v < m_graphFilled.GetVertexCount(); ++v) {
            for (int u : m_graph.GetAdjacencyList()[v]) {
                if (!m_graphFilled.GetAdjacencyList()[v].empty() && std::find(m_graphFilled.GetAdjacencyList()[v].begin(), m_graphFilled.GetAdjacencyList()[v].end(), u) == m_graphFilled.GetAdjacencyList()[v].end()) {
                    m_graphFilled.AddEdge(v, u);
                    added = true;
                }
            }
        }
        if (!added) break;
    }
}

void CGammaAlgorithm::Completion() {
    std::cout << "Graph successfully processed using Gamma Algorithm." << std::endl;
}
